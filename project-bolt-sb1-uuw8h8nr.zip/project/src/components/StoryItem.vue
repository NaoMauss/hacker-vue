<script setup lang="ts">
defineProps<{
  title: string;
  url: string;
  score: number;
  by: string;
  time: number;
  descendants: number;
}>()

function formatTime(timestamp: number): string {
  const hours = Math.floor((Date.now() - timestamp * 1000) / (1000 * 60 * 60));
  return `${hours} hours ago`;
}
</script>

<template>
  <div class="bg-white neo-brutalist p-4 mb-4">
    <h2 class="text-xl font-bold mb-2">
      <a :href="url" target="_blank" class="hover:text-neo-orange">{{ title }}</a>
    </h2>
    <div class="text-sm">
      <span>{{ score }} points</span>
      <span class="mx-2">by {{ by }}</span>
      <span>{{ formatTime(time) }}</span>
      <span class="mx-2">| {{ descendants }} comments</span>
    </div>
  </div>
</template>