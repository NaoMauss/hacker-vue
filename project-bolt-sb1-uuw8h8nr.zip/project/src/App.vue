<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import StoryItem from './components/StoryItem.vue'

const stories = ref<any[]>([])
const loading = ref(true)

async function fetchStories() {
  try {
    const topStoriesRes = await axios.get('https://hacker-news.firebaseio.com/v0/topstories.json')
    const storyIds = topStoriesRes.data.slice(0, 30)
    
    const storyPromises = storyIds.map(id =>
      axios.get(`https://hacker-news.firebaseio.com/v0/item/${id}.json`)
    )
    
    const storyResponses = await Promise.all(storyPromises)
    stories.value = storyResponses.map(res => res.data)
    loading.value = false
  } catch (error) {
    console.error('Error fetching stories:', error)
    loading.value = false
  }
}

onMounted(() => {
  fetchStories()
})
</script>

<template>
  <div class="min-h-screen p-8">
    <header class="mb-8">
      <h1 class="text-4xl font-black mb-4 bg-black text-neo-yellow p-4 inline-block neo-brutalist">
        Neo Hacker News
      </h1>
      <button @click="fetchStories" class="neo-button ml-4">
        Refresh
      </button>
    </header>

    <main>
      <div v-if="loading" class="text-2xl font-bold">
        Loading stories...
      </div>
      <div v-else>
        <StoryItem
          v-for="story in stories"
          :key="story.id"
          v-bind="story"
        />
      </div>
    </main>
  </div>
</template>