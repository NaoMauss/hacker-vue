export default {
  content: [
    "./index.html",
    "./src/**/*.{vue,js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      boxShadow: {
        'brutal': '4px 4px 0px 0px #000000',
      },
      colors: {
        'neo-yellow': '#FFE600',
        'neo-orange': '#FF8A00',
      }
    },
  },
  plugins: [],
}